<?php
//Menampilkan Response dengan Format Auto JSON)
header('Content-Type:application/json');

	//Import File Koneksi Database
	require_once('connect.php');
	
	//Membuat SQL Query
	$sql = "SELECT * FROM data_asn";
	
	//Mendapatkan Hasil
	$r = mysqli_query($con,$sql);
	
	//Membuat Array Kosong 
	$result = array();
	
	while($row = mysqli_fetch_array($r)){
		
		//Memasukkan Nama dan ID kedalam Array Kosong yang telah dibuat 
		array_push($result,array(
		"id"=>$row['id'],
		"nama"=>$row['nama'],
		"nip"=>$row['nip'],
		"pangkat"=>$row['pangkat'],
		"bidang"=>$row['bidang']
		));
	}
	
	//Menampilkan Array 
	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);
?>