<?php
if($_SERVER['REQUEST_METHOD']=='PUT'){
		//MEndapatkan Nilai Dari Variable 
		$id = ''; 
		if( isset( $_GET['id'])) {
    		$id = $_GET['id']; 
		} 

		$nama = ''; 
		if( isset( $_GET['nama'])) {
    		$nama = $_GET['nama']; 
		} 

		$nip = ''; 
		if( isset( $_GET['nip'])) {
   			 $nip = $_GET['nip']; 
		} 

		$pangkat = ''; 
		if( isset( $_GET['pangkat'])) {
    		$pangkat = $_GET['pangkat']; 
		} 

		$bidang = ''; 
		if( isset( $_GET['bidang'])) {
    		$bidang = $_GET['bidang']; 
		} 
		
		//import file koneksi database 
		require_once('connect.php');
		
		//Membuat SQL Query
		$sql = "UPDATE data_asn SET nama = '$nama', nip = '$nip', pangkat = '$pangkat' , bidang = '$bidang' WHERE id = $id;";
		
		//Meng-update Database 
		if(mysqli_query($con,$sql)){
		echo 'Berhasil Update Data ASN';
		}else{
		echo 'Gagal Update Data ASN';
		}
		
		mysqli_close($con);
	}
?>