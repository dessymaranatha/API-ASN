<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		//Mendapatkan Nilai Variable
		$id = ''; 
		if( isset( $_GET['id'])) {
    		$id = $_GET['id']; 
		} 

		$nama = ''; 
		if( isset( $_GET['nama'])) {
    		$nama = $_GET['nama']; 
		} 

		$nip = ''; 
		if( isset( $_GET['nip'])) {
   			 $nip = $_GET['nip']; 
		} 

		$pangkat = ''; 
		if( isset( $_GET['pangkat'])) {
    		$pangkat = $_GET['pangkat']; 
		} 

		$bidang = ''; 
		if( isset( $_GET['bidang'])) {
    		$bidang = $_GET['bidang']; 
		} 

		//Pembuatan Syntax SQL
		$sql = "INSERT INTO data_asn (nama,nip,pangkat,bidang) VALUES ('$nama','$nip','$pangkat','$bidang')";
		
		//Import File Koneksi database
		require_once('connect.php');
		
		//Eksekusi Query database
		if(mysqli_query($con,$sql)){
		echo 'Berhasil Menambahkan Data ASN';
		}else{
		echo 'Gagal Menambahkan Data ASN';
		}
		
		mysqli_close($con);
	}
?>